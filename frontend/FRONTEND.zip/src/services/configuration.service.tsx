export const CONFIG = {
    //  url: 'http://localhost:5000/', 
    url: 'http://localhost:5000/',
    url_socket: 'http://localhost:5000/notify',
    versionApi: 'api',
};
